/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package game;
import java.awt.*;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.util.ArrayList;
/**
 *
 * @author twin
 */
public class Character {
    
    private double x;
    private double y;
    private int r;
    private double dx;
    private double dy;
    private int width;
    private int height;
    private boolean left;
    private boolean right;
    private boolean up;
    private boolean down;
    private double moveSpeed;
    private double maxSpeed;
    private double stopSpeed;
    private final Tilemap tilemap;
    private boolean topleft;
    private boolean topright;
    private boolean botleft;
    private boolean botright;
    public boolean Dead;
    public static ArrayList<Projectile> projectile;
    private Animation animation;
    private BufferedImage[] movrightSprite;
    private BufferedImage[] movleftSprite;
    private BufferedImage[] movupSprite;
    private BufferedImage[] movdownSprite;
    private BufferedImage[] idleUpSprite;
    private BufferedImage[] idleDownSprite;
    private BufferedImage[] idleRightSprite;
    private BufferedImage[] idleLeftSprite;
    private BufferedImage[] movrightSprite_HIT;
    private BufferedImage[] movleftSprite_HIT;
    private BufferedImage[] movupSprite_HIT;
    private BufferedImage[] movdownSprite_HIT;
    private BufferedImage[] idleUpSprite_HIT;
    private BufferedImage[] idleDownSprite_HIT;
    private BufferedImage[] idleRightSprite_HIT;
    private BufferedImage[] idleLeftSprite_HIT;
    private boolean facingLeft;
    private boolean facingDown;
    private boolean facingRight;
    private boolean facingUp;
    private boolean firing;
    private long firingTimer;
    private long firingDelay;
    private int Shield;
    private int ShieldAux;
    private int lives;
    private boolean recovering;
    private long recoveryTimer;
    private int powerLevel;
    private int power;
    private int [] requiredPower={1,2,3,4,5,6,7,8,9,10};
    
   public Character(Tilemap tm){
    tilemap =tm;
    /*width=64;
    height=64;*/
    width=32;
    height=32;
    moveSpeed=2.5;
    maxSpeed=6;
    stopSpeed=4;
    r=5;
    lives=5;
    Shield=0;
    ShieldAux=Shield;
    try{
        idleDownSprite=new BufferedImage[1];
        idleUpSprite=new BufferedImage[1];
        idleRightSprite=new BufferedImage[1];
        idleLeftSprite=new BufferedImage[1];
        movrightSprite=new BufferedImage[3];
        movleftSprite=new BufferedImage[3];
        movupSprite=new BufferedImage[3];
        movdownSprite=new BufferedImage[3];
        
        idleDownSprite_HIT=new BufferedImage[2];
        idleUpSprite_HIT=new BufferedImage[2];
        idleRightSprite_HIT=new BufferedImage[2];
        idleLeftSprite_HIT=new BufferedImage[2];
        movrightSprite_HIT=new BufferedImage[8];
        movleftSprite_HIT=new BufferedImage[8];
        movupSprite_HIT=new BufferedImage[8];
        movdownSprite_HIT=new BufferedImage[8];
        
        
        
        idleDownSprite[0]=ImageIO.read(new File("graphics/IDLE_DOWN.png"));
        idleUpSprite[0]=ImageIO.read(new File("graphics/IDLE_UP.png"));
        idleLeftSprite[0]=ImageIO.read(new File("graphics/IDLE_LEFT.png"));
        idleRightSprite[0]=ImageIO.read(new File("graphics/IDLE_RIGHT.png"));
        BufferedImage moveright=ImageIO.read(new File("graphics/SPRITE_RIGTH.png"));
        BufferedImage moveleft=ImageIO.read(new File("graphics/SPRITE_LEFT.png"));
        BufferedImage moveup=ImageIO.read(new File("graphics/SPRITE_UP.png"));
        BufferedImage movedown=ImageIO.read(new File("graphics/SPRITE_DOWN.png"));
        //
        BufferedImage moveright_HIT=ImageIO.read(new File("graphics/SPRITE_RIGTH_HIT.png"));
        BufferedImage moveleft_HIT=ImageIO.read(new File("graphics/SPRITE_LEFT_HIT.png"));
        BufferedImage moveup_HIT=ImageIO.read(new File("graphics/SPRITE_UP_HIT.png"));
        BufferedImage movedown_HIT=ImageIO.read(new File("graphics/SPRITE_DOWN_HIT.png"));
        BufferedImage idleRight_HIT=ImageIO.read(new File("graphics/SPRITE_RIGTH_HIT.png"));
        BufferedImage idleLeft_HIT=ImageIO.read(new File("graphics/SPRITE_LEFT_HIT.png"));
        BufferedImage idleUp_HIT=ImageIO.read(new File("graphics/SPRITE_UP_HIT.png"));
        BufferedImage idleDown_HIT=ImageIO.read(new File("graphics/SPRITE_DOWN_HIT.png"));
        
        for(int i=0;i<3;i++){
        movrightSprite[i]=moveright.getSubimage(i*width,0,width,height);
        movleftSprite[i]=moveleft.getSubimage(i*width,0,width,height);
        movupSprite[i]=moveup.getSubimage(i*width,0,width,height);
        movdownSprite[i]=movedown.getSubimage(i*width,0,width,height);
        }
        for(int i=0;i<2;i++){
        idleDownSprite_HIT[i]=idleDown_HIT.getSubimage(i*width,0,width,height);
        idleUpSprite_HIT[i]=idleUp_HIT.getSubimage(i*width,0,width,height);
        idleRightSprite_HIT[i]=idleRight_HIT.getSubimage(i*width,0,width,height);
        idleLeftSprite_HIT[i]=idleLeft_HIT.getSubimage(i*width,0,width,height);
        }
        for(int i=0;i<8;i++){
        movrightSprite_HIT[i]=moveright_HIT.getSubimage(i*width,0,width,height);
        movleftSprite_HIT[i]=moveleft_HIT.getSubimage(i*width,0,width,height);
        movupSprite_HIT[i]=moveup_HIT.getSubimage(i*width,0,width,height);
        movdownSprite_HIT[i]=movedown_HIT.getSubimage(i*width,0,width,height);
        }
        
        
        
    }catch(Exception e){
    e.printStackTrace();
    }
    
    animation=new Animation();
    facingLeft=false;
    facingDown=false;
    facingRight=false;
    facingUp=false;
    
    firing=false;
    firingTimer=System.nanoTime();
    firingDelay=200;
    
    projectile=new ArrayList<Projectile>();
    recovering=false;
    recoveryTimer=0;
    
    
   }
   
   public void setLeft(boolean b){
   left=b;
   }
   public void setRight(boolean b){
   right=b;
   }
   public void setUp(boolean b){
   up=b;
   }
   public void setDown(boolean b){
   down=b;
   }
   public void setX(int i){
   x=i;
   }
   public void setY(int i){
   y=i;
   }
   
   public int getx(){
   return (int) x;
   }
   public int gety(){
   return (int) y;
   }
   public int getr(){
   return r;
   }
   public int getLives(){
   return lives;
   }
   public boolean isRecovering(){
   return recovering;
   }
   public int getw(){
   return width;
   }
   public int geth(){
   return height;
   }
   
   public void setFiring(boolean b){
   firing=b;
   }
   public void loseLife(){
    ShieldAux--;
   recovering=true;
   recoveryTimer=System.nanoTime();
       if(ShieldAux<=0){
   lives--;
   recovering=true;
   recoveryTimer=System.nanoTime();
   ShieldAux=Shield;
       }
   }
   
   public void gainLife(){
       lives++;
   }
   
   public void gainShield(){
   Shield=Shield+1;
   }
   
   public void increasePower(int i){
   power+=i;
   if(power>=requiredPower[powerLevel]){
   power-=requiredPower[powerLevel];
   powerLevel++;
   }
   }
   
   public int getPowerLevel(){
   return powerLevel;
   }
   
   int getPower(){
   return power;}
   
   public int getRequiredPower(){
   return requiredPower[powerLevel];
   }
   
   
   /*public void Shield(){
   ShieldAux--;
   }*/
   
     public void setShield(int Shield) {
        this.Shield = Shield;
    }

    public int getShield() {
        return Shield;
    }
    
     public boolean isDead() {
        return lives<=0;
    }  
   
   private void calculateCorners(double x,double y){
       int leftTile= tilemap.getColTile((int) (x-width/2));
       int rightTile= tilemap.getColTile((int) (x+width/2));
       int topTile= tilemap.getColTile((int) (y-width/2));
       int botTile= tilemap.getColTile((int) (y+width/2));
       topleft=tilemap.isBlocked(topTile, leftTile);
       topright=tilemap.isBlocked(topTile, rightTile);
       botleft=tilemap.isBlocked(botTile, leftTile);
       botright=tilemap.isBlocked(botTile, rightTile);
   }
   
   ////////////////////////////////////////////////////////////
   public void update(){
   //////revisar diagonal!!!
       //determinar la siguiente posición
       if(left){
       dx-=moveSpeed;
       if(dx < -maxSpeed)
           dx=-maxSpeed;
           dy=0;
       }
       else if(right){
       dx+=moveSpeed;
       if(dx > maxSpeed)
           dx=maxSpeed;
           dy=0;
       }
       else if(up){
       dy-=moveSpeed;
       if(dy < -maxSpeed)
           dy=-maxSpeed;
           dx=0;
       }
       else if(down){
       dy+=moveSpeed;
       if(dy > maxSpeed)
          dy=maxSpeed;
          dx=0;
       }
       else if (dx>0){
           dx-=stopSpeed;
       if (dx<0)
           dx=0;
       }
       else if (dx<0){
           dx=stopSpeed;
       if (dx>0)
           dx=0;
       }
       else if (dy>0){
           dy-=stopSpeed;
       if (dy<0)
           dy=0;
       }
       else if (dy<0){
           dy=stopSpeed;
       if (dy>0)
           dy=0;
       }
       
       if(firing){
       long elapsed=(System.nanoTime()-firingTimer)/2500000;
       if(elapsed >firingDelay){
           firingTimer=System.nanoTime();
          if(powerLevel<2){ 
           if(facingUp)
       projectile.add(new Projectile(270,x,y,tilemap));
       
           if(facingDown)
       projectile.add(new Projectile(90,x,y,tilemap));
       //firingTimer=System.nanoTime();
       if(facingRight)
       projectile.add(new Projectile(360,x,y,tilemap));
      // firingTimer=System.nanoTime();
       if(facingLeft)
       projectile.add(new Projectile(180,x,y,tilemap));
      // firingTimer=System.nanoTime();
        }
             else if(powerLevel<5){
                if(facingUp){
                projectile.add(new Projectile(270,x,y,tilemap));
                projectile.add(new Projectile(270,x+15,y,tilemap));
                }
                if(facingDown){
                projectile.add(new Projectile(90,x,y,tilemap));
                projectile.add(new Projectile(90,x+15,y,tilemap));
                }
                if(facingRight){
                projectile.add(new Projectile(360,x,y,tilemap));
                projectile.add(new Projectile(360,x,y-15,tilemap));
                }
                if(facingLeft){
                projectile.add(new Projectile(180,x,y,tilemap));
                projectile.add(new Projectile(180,x,y-15,tilemap));
                }
       
                }
       }
       }
       
       long elapsed=(System.nanoTime()-recoveryTimer)/1000000;
       if(elapsed>1500){
           recovering=false;
           recoveryTimer=0;
       }
       
       
       
       //coliciones
       
       int currCol=tilemap.getColTile((int) x);
       int currRow=tilemap.getRowTile((int) y);
       double ndx=x+dx;   /// nd=nuevoDestino luego del update
       double ndy=y+dy;
       double tempx=x;
       double tempy=y;
       
       calculateCorners(x,ndy);
       if(dy<0){
       if(topleft||topright){
       dy=0;
       tempy=currRow*tilemap.getTileSize()+height/2;
       }
       else{
       tempy+=dy;
           }
       }
       if(dy>0){
           if(botleft||botright){
        dy=0;
         tempy=(currRow+0.998)*tilemap.getTileSize()-height/2;
       }
       else{
       tempy+=dy;
       }
     }
     calculateCorners(ndx,y);
       if(dx<0){
       if(topleft||botleft){
       dx=0;
       tempx=currCol*tilemap.getTileSize()+width/2;
       }
       else{
       tempx+=dx;
       } 
       }
       if(dx>0){
       if(topright||botright){  
           dx=0;
          //tempx=(currCol+0.498)*tilemap.getTileSize()+width/2;
       }
       else{
           tempx+=dx;
       }
   }
       x=tempx;
       y=tempy;
       //moviendo el mapa
       tilemap.setX((int) (GamePanel.width/2-x));
       tilemap.setY((int) (GamePanel.height/2-y));
       
       //animacion sprite
        if(dx<0){
           facingLeft=true;
           facingRight=false;
           facingUp=false;
           facingDown=false;
     }  
       if(dx>0){
           facingRight=true;
           facingLeft=false;
           facingUp=false;
           facingDown=false;
       }
       if(dy>0){
           facingDown=true;
           facingUp=false;
           facingLeft=false;
           facingRight=false;
       }
       if(dy<0){
           facingUp=true;
           facingDown=false;
           facingLeft=false;
           facingRight=false;
       }
       //if(recovering){
       
       //}
       
       
       if(right){
           animation.setFrames(movrightSprite);
           animation.setDelay(100);
       }else if(left){
           animation.setFrames(movleftSprite);
           animation.setDelay(100);
       }else if(up){
           animation.setFrames(movupSprite);
           animation.setDelay(100);    
       }else if(down){
           animation.setFrames(movdownSprite);
           animation.setDelay(100);
       }else if(facingUp){
           animation.setFrames(idleUpSprite);
           animation.setDelay(-1);
       }else if(facingRight){
           animation.setFrames(idleRightSprite);
           animation.setDelay(-1);
       }
       else if(facingLeft){
           animation.setFrames(idleLeftSprite);
           animation.setDelay(-1);
       }
       else{
           animation.setFrames(idleDownSprite);
           animation.setDelay(-1);
       }
      animation.update();
      
       for(int i=0;i<projectile.size();i++){
        projectile.get(i).update();
      //  if(remove){
        //pro
        //}
       }
      
       
}     
       
   public void draw(Graphics2D g){
   
       int tx=tilemap.getX();
       int ty=tilemap.getY();
       if(recovering){
           if(right){
           animation.setFrames(movrightSprite_HIT);
           animation.setDelay(2);
       }else if(left){
           animation.setFrames(movleftSprite_HIT);
           animation.setDelay(2);
       }else if(up){
           animation.setFrames(movupSprite_HIT);
           animation.setDelay(2);    
       }else if(down){
           animation.setFrames(movdownSprite_HIT);
           animation.setDelay(2);
       }else if(facingUp){
           animation.setFrames(idleUpSprite_HIT);
           animation.setDelay(2);
       }else if(facingRight){
           animation.setFrames(idleRightSprite_HIT);
           animation.setDelay(2);
       }
       else if(facingLeft){
           animation.setFrames(idleLeftSprite_HIT);
           animation.setDelay(2);
       }
       else{
           animation.setFrames(idleDownSprite_HIT);
           animation.setDelay(2);
       }
       g.drawImage(animation.getImage(), (int)(tx+x-width/2),(int) (ty+y-height/2),null);

       }else
       
       g.drawImage(animation.getImage(), (int)(tx+x-width/2),(int) (ty+y-height/2),null);
      /* if(facingLeft){
       g.drawImage(animation.getImage(), (int)(tx+x-width/2),(int) (ty+y-height/2),null);
       }else{
       g.drawImage(animation.getImage(),(int) (tx+x-width/2+width),(int) (ty+y-height/2),-width,height,null);
       }
       if(facingDown){
           g.drawImage(animation.getImage(),(int) (tx+x-width/2),(int) (ty+y-height/2+height),width,-height,null);
      
       }else{
        g.drawImage(animation.getImage(), (int)(tx+x-width/2),(int) (ty+y-height/2),null);
       }*/
       
       //g.setColor(Color.BLUE);
       //g.fillRect((int) (tx+x-width/2), (int) (ty+y-height/2), width, height);
       for(int i=0;i<projectile.size();i++){
        projectile.get(i).draw(g);
       }
   }
   
}
