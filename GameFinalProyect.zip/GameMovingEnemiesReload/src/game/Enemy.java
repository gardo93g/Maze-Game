/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package game;
import java.awt.*;
import java.awt.image.*;
import java.io.File;
import java.util.ArrayList;
import javax.imageio.ImageIO;

/**
 *
 * @author TWIN
 */
public class Enemy {
    //
    private double x;
    private double y;
    private double ntx;
    private double nty;
    private int r;
    private int width;
    private int height;
    private double dx;
    private double dy;
    private double speed;
    private double rad;
    private int HP; //healtpoints
    private int type;
    private int rank;
    private Color color1;
    private Color color2;
    private Color color3;
    private boolean ready;
    private boolean dead;
    private final Tilemap tilemap;
    public static ArrayList<ProjectileBoss> projectile;
    private boolean topleft;
    private boolean topright;
    private boolean botleft;
    private boolean botright;
    private int leftTile;
    private int rightTile;
    private int topTile;
    private int botTile;
    private BufferedImage[] enemySprite;
    private BufferedImage[] enemySprite2;
    private BufferedImage[] enemySprite3;
    private BufferedImage[] enemySprite4;
    private BufferedImage[] enemySprite5;
    private BufferedImage[] enemySprite6;
    private BufferedImage[] enemySprite7;
    private BufferedImage[] enemySprite8;
    private BufferedImage[] enemySprite9;
    private BufferedImage[] enemyBoss1;
    private BufferedImage[] enemyBoss2;
   // private BufferedImage[] explosion;
    private Animation animation;
    private boolean enemy;
    private boolean enemy2;
    private boolean enemy3;
    private boolean enemy4;
    private boolean enemy5;
    private boolean enemy6;
    private boolean enemy7;
    private boolean enemy8;
    private boolean enemy9;
    private boolean enemy10;
    private boolean enemy11;
    private long firingTimer;
    private long firingDelay;
    private boolean ehit;
    
    //CONSTRUCTOR
    public Enemy(int type,int rank,int x,int y,Tilemap tilemap,boolean moving){
   
    this.type=type;
    this.rank=rank;
    this.x=x;
    this.y=y;
    this.tilemap=tilemap;
    moving=false;
    enemySprite=new BufferedImage[3];
    enemySprite2=new BufferedImage[8];
    enemySprite3=new BufferedImage[5];
    enemySprite4=new BufferedImage[3];
    enemySprite5=new BufferedImage[8];
    enemySprite6=new BufferedImage[5];
    enemySprite7=new BufferedImage[3];
    enemySprite8=new BufferedImage[8];
    enemySprite9=new BufferedImage[5];
    enemyBoss1=new BufferedImage[3];
    enemyBoss2=new BufferedImage[3];
   // explosion=new BufferedImage[4];
    if(rank==1){
    speed=3;
    HP=1;
    if(type==1){
    enemy=true;
    enemy2=enemy3=enemy4=enemy5=enemy6=enemy7=enemy8=enemy9=enemy10=enemy11=false;
    width=16;
    height=16;
    try{
    BufferedImage enemSprite=ImageIO.read(new File("graphics/enemr1t1.png"));
    for(int i=0;i<3;i++){
        enemySprite[i]=enemSprite.getSubimage(i*width,0,width,height);
    }
    }catch(Exception e){
    e.printStackTrace();
    }
     }
    if(type==2){
     enemy2=true;
    enemy=enemy3=enemy4=enemy5=enemy6=enemy7=enemy8=enemy9=enemy10=enemy11=false;
     width=18;
     height=16;
    double angle=Math.random()*120;
      try{
    BufferedImage enemSprite2=ImageIO.read(new File("graphics/enemr1t2.png"));
    for(int i=0;i<8;i++){
        enemySprite2[i]=enemSprite2.getSubimage(i*width,0,width,height);
    }
    }catch(Exception e){
    e.printStackTrace();
    }
     }
    if(type==3){
    enemy3=true;
    enemy2=enemy=enemy4=enemy5=enemy6=enemy7=enemy8=enemy9=enemy10=enemy11=false;
    width=32;
    height=30;
    double angle=Math.random()*50;
      try{
    BufferedImage enemSprite3=ImageIO.read(new File("graphics/enemr1t3.png"));
    for(int i=0;i<5;i++){
        enemySprite3[i]=enemSprite3.getSubimage(i*width,0,width,height);
    }
    }catch(Exception e){
    e.printStackTrace();
    }
        }
    }else if(rank==2){
    speed=4;
    HP=4;
    if(type==1){
    enemy4=true;
    enemy2=enemy3=enemy=enemy5=enemy6=enemy7=enemy8=enemy9=enemy10=enemy11=false;
    width=32;
    height=32;
    try{
    BufferedImage enemSprite4=ImageIO.read(new File("graphics/enemr2t1.png"));
    for(int i=0;i<3;i++){
        enemySprite4[i]=enemSprite4.getSubimage(i*width,0,width,height);
    }
    }catch(Exception e){
    e.printStackTrace();
    }
     }
    if(type==2){
     enemy5=true;
    enemy=enemy3=enemy4=enemy2=enemy6=enemy7=enemy8=enemy9=enemy10=enemy11=false;
     width=18;
     height=16;
    double angle=Math.random()*120;
      try{
    BufferedImage enemSprite5=ImageIO.read(new File("graphics/enemr2t2.png"));
    for(int i=0;i<8;i++){
        enemySprite5[i]=enemSprite5.getSubimage(i*width,0,width,height);
    }
    }catch(Exception e){
    e.printStackTrace();
    }
     }
    if(type==3){
    enemy6=true;
    enemy2=enemy=enemy4=enemy5=enemy3=enemy7=enemy8=enemy9=enemy10=enemy11=false;
    width=32;
    height=30;
    double angle=Math.random()*50;
      try{
    BufferedImage enemSprite6=ImageIO.read(new File("graphics/enemr2t3.png"));
    for(int i=0;i<5;i++){
        enemySprite6[i]=enemSprite6.getSubimage(i*width,0,width,height);
    }
    }catch(Exception e){
    e.printStackTrace();
    }
        }
    }else if(rank==3){
    speed=3;
    HP=6;
    if(type==1){
    enemy7=true;
    enemy2=enemy3=enemy=enemy5=enemy6=enemy4=enemy8=enemy9=enemy10=enemy11=false;
    width=32;
    height=32;
    try{
    BufferedImage enemSprite7=ImageIO.read(new File("graphics/enemr3t1.png"));
    for(int i=0;i<3;i++){
        enemySprite7[i]=enemSprite7.getSubimage(i*width,0,width,height);
    }
    }catch(Exception e){
    e.printStackTrace();
    }
     }
    if(type==2){
     enemy8=true;
    enemy=enemy3=enemy4=enemy2=enemy6=enemy7=enemy5=enemy9=enemy10=enemy11=false;
     width=18;
     height=16;
    double angle=Math.random()*120;
      try{
    BufferedImage enemSprite8=ImageIO.read(new File("graphics/enemr3t2.png"));
    for(int i=0;i<8;i++){
        enemySprite8[i]=enemSprite8.getSubimage(i*width,0,width,height);
    }
    }catch(Exception e){
    e.printStackTrace();
    }
     }
    if(type==3){
    enemy9=true;
    enemy2=enemy=enemy4=enemy5=enemy3=enemy7=enemy8=enemy6=enemy10=enemy11=false;
    width=32;
    height=30;
    double angle=Math.random()*50;
      try{
    BufferedImage enemSprite9=ImageIO.read(new File("graphics/enemr3t3.png"));
    for(int i=0;i<5;i++){
        enemySprite9[i]=enemSprite9.getSubimage(i*width,0,width,height);
    }
    }catch(Exception e){
    e.printStackTrace();
    }
        }
    }
    else if(rank==4){
    speed=3;
    HP=10;
    if(type==1){
    enemy10=true;
    enemy2=enemy3=enemy=enemy5=enemy6=enemy4=enemy8=enemy9=enemy7=enemy11=false;
    width=64;
    height=64;
    try{
    BufferedImage enemBoss1=ImageIO.read(new File("graphics/enemr4t1.png"));
    for(int i=0;i<3;i++){
        enemyBoss1[i]=enemBoss1.getSubimage(i*width,0,width,height);
    }
    }catch(Exception e){
    e.printStackTrace();
    }
        }
    if(type==2){  
    enemy11=true;
    enemy2=enemy3=enemy=enemy5=enemy6=enemy4=enemy8=enemy9=enemy7=enemy10=false;
    width=70;
    height=70;
    try{
    BufferedImage enemBoss2=ImageIO.read(new File("graphics/enemr4t2.png"));
    for(int i=0;i<3;i++){
        enemyBoss2[i]=enemBoss2.getSubimage(i*width,0,width,height);
    }
    }catch(Exception e){
    e.printStackTrace();
    }
        }
             }
    
    
    x=(int) (Math.random() *GamePanel.width/2+ GamePanel.width/4);
    y=-r*50;//*200;
    double angle=Math.random()*120+60;
    rad=Math.toRadians(angle);
    dx=Math.cos(rad)*speed;
    dy=Math.sin(rad)*speed;
    ready=false;
    dead=false;
    animation=new Animation();
    firingTimer=System.nanoTime();
    firingDelay=500;
    projectile=new ArrayList<ProjectileBoss>();
    ehit=false;
    
 }

   // public Enemy(int type,int rank){}
    
    public double getX(){
   return x;
   }
   public double getY(){
   return y;
   }
   public double getR(){
   return r;
   }
   
   public int getWidth() {
        return width;
    }
   public boolean isDead(){
   
   return dead;
   }
  public double getNtx() {
      int tx=tilemap.getX();
        
        return ntx;
    }

    public double getNty() {
         int ty=tilemap.getY();
        
        return nty;
    }
    
    public int getType() {
        return type;
    }
    
    public int getRank() {
        return rank;
    }
    
    public Tilemap getTilemap() {
        return tilemap;
    }
    

   
   //FUNCTION
   
   public void hit(){
   HP--;
   if(rank==4)
   ehit=true;
   speed+=0.5;
   if(HP<=0){
   dead=true;
    }
 }
  
   private void calculateCorners(double x,double y){
       leftTile= tilemap.getColTile((int) (x-width/2));
       rightTile= tilemap.getColTile((int) (x+width/2));
       topTile= tilemap.getColTile((int) (y-height/2));
       botTile= tilemap.getColTile((int) (y+height/2));
       
       topleft=tilemap.isBlocked(topTile, leftTile);
       topright=tilemap.isBlocked(topTile, rightTile);
       botleft=tilemap.isBlocked(botTile, leftTile);
       botright=tilemap.isBlocked(botTile, rightTile);
   }
   
   
   
    public void update(){
        
   x+=dx;
   y+=dy;
       int currCol=tilemap.getColTile((int) x);
       int currRow=tilemap.getRowTile((int) y);
       double ndx=x+dx;   /// nd=nuevoDestino luego del update
       double ndy=y+dy;
       double tempx=x;
       double tempy=y;
       
      calculateCorners(x,ndy);
       if(dy<0){
       if(topleft){
       dy+=(1*speed)-(6/5)*dy;
       
       tempy=currRow*tilemap.getTileSize()+height/2;
       }
       else if(topright){
       dy-=(1*speed)+(6/5)*dy;
       
       tempy=currRow*tilemap.getTileSize()+height/2;
       }
       else{
       tempy+=dy-dy;
           }
       }
       if(dy>0){
           if(botleft){
        dy-=(1*speed)+(6/5)*dy;
        
         tempy=(currRow+0.998)*tilemap.getTileSize()-height/2;
       }
        else if(botright){
        dy+=(1*speed)-(6/5)*dy;
        
         tempy=(currRow+0.998)*tilemap.getTileSize()-height/2;
       }
       else{
       tempy+=dy-dy;
       }
     }
       
       
     calculateCorners(ndx,y);
       if(dx<0){
       if(topleft){
       dx+=(1*speed)-(6/5)*dx;
       
       tempx=(currCol)*tilemap.getTileSize()+width/2;
       }
       else if(botleft){
       dx+=(1*speed)-(6/5)*dx;
       
       tempx=(currCol)*tilemap.getTileSize()+width/2;
       }
       else{
       tempx+=dx-dx;
       } 
      }
       
       if(dx>0){
       if(topright){  
           dx-=(1*speed)+(6/5)*dx;
          tempx=(currCol+0.498)*tilemap.getTileSize() +width/2;
       }
       else if(botright){  
           dx-=(1*speed)+(6/5)*dx;
          tempx=(currCol+0.498)*tilemap.getTileSize() +width/2;
          
       }
       else{
           tempx+=dx-dx;
       }
   }
       x=tempx;
       y=tempy;
       
      
  // }  
       if(enemy){
       animation.setFrames(enemySprite);
       animation.setDelay(200);
       }
       else if(enemy2){
       animation.setFrames(enemySprite2);
       animation.setDelay(200);
       }
       else if(enemy3){
       animation.setFrames(enemySprite3);
       animation.setDelay(100);
       }
       else if(enemy4){
       animation.setFrames(enemySprite4);
       animation.setDelay(100);
       }
        else if(enemy5){
       animation.setFrames(enemySprite5);
       animation.setDelay(100);
       }else if(enemy6){
       animation.setFrames(enemySprite6);
       animation.setDelay(100);
       }else if(enemy7){
       animation.setFrames(enemySprite7);
       animation.setDelay(100);
       }else if(enemy8){
       animation.setFrames(enemySprite8);
       animation.setDelay(100);
       }
       else if(enemy10){
       animation.setFrames(enemyBoss1);
       animation.setDelay(100);
       }else if(enemy9){
       animation.setFrames(enemySprite9);
       animation.setDelay(100);
       }else{
       animation.setFrames(enemyBoss2);
       animation.setDelay(100);
       }
       
       if(ehit && HP>3){
       long elapsed=(System.nanoTime()-firingTimer)/2500000;
       if(elapsed >firingDelay){
       projectile.add(new ProjectileBoss(60,x,y,tilemap));
       projectile.add(new ProjectileBoss(120,x,y,tilemap));
       projectile.add(new ProjectileBoss(180,x,y,tilemap));
       projectile.add(new ProjectileBoss(240,x,y,tilemap));
       projectile.add(new ProjectileBoss(300,x,y,tilemap));
       projectile.add(new ProjectileBoss(360,x,y,tilemap));
       }
       ehit=false;
       }
       
       if(ehit && rank==4 && HP<=3){
       long elapsed=(System.nanoTime()-firingTimer)/2500000;
       if(elapsed >firingDelay){
       projectile.add(new ProjectileBoss(60,x,y,tilemap));
       projectile.add(new ProjectileBoss(120,x,y,tilemap));
       projectile.add(new ProjectileBoss(180,x,y,tilemap));
       projectile.add(new ProjectileBoss(240,x,y,tilemap));
       projectile.add(new ProjectileBoss(300,x,y,tilemap));
       projectile.add(new ProjectileBoss(360,x,y,tilemap));
       projectile.add(new ProjectileBoss(60+20,x,y,tilemap));
       projectile.add(new ProjectileBoss(120+20,x,y,tilemap));
       projectile.add(new ProjectileBoss(180+20,x,y,tilemap));
       projectile.add(new ProjectileBoss(240+20,x,y,tilemap));
       projectile.add(new ProjectileBoss(300+20,x,y,tilemap));
       projectile.add(new ProjectileBoss(360+20,x,y,tilemap));
       }
       ehit=false;
       }
       
       if(ehit && rank==4 && HP<=3 &&type==2){
       long elapsed=(System.nanoTime()-firingTimer)/2500000;
       if(elapsed >firingDelay){
       projectile.add(new ProjectileBoss(60,x,y,tilemap));
       projectile.add(new ProjectileBoss(120,x,y,tilemap));
       projectile.add(new ProjectileBoss(180,x,y,tilemap));
       projectile.add(new ProjectileBoss(240,x,y,tilemap));
       projectile.add(new ProjectileBoss(300,x,y,tilemap));
       projectile.add(new ProjectileBoss(360,x,y,tilemap));
       projectile.add(new ProjectileBoss(60+20,x,y,tilemap));
       projectile.add(new ProjectileBoss(120+20,x,y,tilemap));
       projectile.add(new ProjectileBoss(180+20,x,y,tilemap));
       projectile.add(new ProjectileBoss(240+20,x,y,tilemap));
       projectile.add(new ProjectileBoss(300+20,x,y,tilemap));
       projectile.add(new ProjectileBoss(360+20,x,y,tilemap));
       }
       ehit=false;
       }
       
       
       animation.update();
       for(int i=0;i<projectile.size();i++){
        projectile.get(i).update();
       }
       // exploding=false;
       
   }
    
   
    public void draw(Graphics2D g){
  // g.setColor(color1);
   int tx=tilemap.getX();
     int ty=tilemap.getY();
         int nx=  (int) (tx+x-width/2);
         int ny=  (int) (ty+y-height/2);
   g.drawImage(animation.getImage(),nx,ny,null);
   for(int i=0;i<projectile.size();i++){
        projectile.get(i).draw(g);
       }
   
   
   }
}


