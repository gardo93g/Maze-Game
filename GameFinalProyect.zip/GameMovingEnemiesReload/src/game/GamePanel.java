/*
 * To change this license header, choose License Headers in Prog2ect Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package game;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.ArrayList;
import MapGenerator.MazeGenerator;
/**
 *
 * @author twin
 */
public class GamePanel extends JPanel implements Runnable, KeyListener{
    
    public static final int height=600;
    public static final int width=600;
    
    private Thread thread;
    private boolean running;
     private boolean running2;
    private BufferedImage image;
    private Graphics2D g;
    private final int FPS=35;
    private final int targetTime=1000/FPS;
    public static Tilemap tilemap;
    private Character character;
    public static ArrayList<Enemy> enemy;
    public static ArrayList<PowerUp> powerup;
    public static int contEnemy;
    private long stageStartTimer;
    private long stageStartTimerDiff;
    private int stageNumber;
    private boolean stageStart;
    private int stageDelay=2500;
    public GamePanel(){
    super();
    setPreferredSize(new Dimension(width,height));
    setFocusable(true);
    requestFocus();
    running=true;
    
    }
    
    //@Override
    public void addNotify(){
    super.addNotify();
    if(thread==null){
    thread=new Thread(this);
    thread.start();
    }
    addKeyListener(this);
    }
   
    
    MazeGenerator mg=new MazeGenerator(5,5);
   
    
   // @Override
    public void run(){
       stageNumber=2;
       mg.GenMapa();
       
        while(running){
    init();
    long startTime;
    long urdTime;
    long waitTime;
    while(running2){
    startTime=System.nanoTime();
    update(); 
    render();
    draw();
    urdTime=(System.nanoTime()-startTime)/1000000;
    waitTime=targetTime-urdTime;
    try{
    Thread.sleep(waitTime);
    }
    catch(Exception e){
    }

     }
        g.setColor(new Color(0,0,0));  
         g.fillRect(0,0,width,height);
        draw();
       startTime=System.nanoTime();
       urdTime=(System.nanoTime()-startTime)/1000000;
       waitTime=targetTime-urdTime;
    
        }
        
     g.setColor(new Color(0,100,255));  
     g.fillRect(0,0,width,height);
     g.setColor(Color.WHITE);
     g.setFont(new Font("Century Gothic",Font.PLAIN,60));
     String s="G A M E O V E R";
     int length=(int)g.getFontMetrics().getStringBounds(s,g).getWidth();
     g.drawString(s,(width-length)/2,height/2);
     draw();
    }
    
    private void init(){
    running2=true;
    image=new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
    
    g=(Graphics2D) image.getGraphics();
    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
    g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
   // character=new Character(tilemap);
    if(stageNumber==0){
    tilemap=new Tilemap("Mapa1.txt",64);
    tilemap.loadTile("graphics/Environment.png");

    }else if(stageNumber==1){
    tilemap=new Tilemap("Mapa2.txt",64);   
    tilemap.loadTile("graphics/Environment.png");

    }else if(stageNumber==2){
    tilemap=new Tilemap("Mapa3.txt",64);   
    tilemap.loadTile("graphics/Environment.png");
    character=new Character(tilemap);
    character.setX(352);
    character.setY(512);
    }else if(stageNumber==3){
    tilemap=new Tilemap("Mapa4.txt",64);   
    tilemap.loadTile("graphics/Environment2.png");
    //character=new Character(tilemap);
    //character.setX(96);
   // character.setY(96);
    }else if(stageNumber==4){
    tilemap=new Tilemap("Mapa5.txt",64);   
    tilemap.loadTile("graphics/Environment2.png");
    }else if(stageNumber==5){
    tilemap=new Tilemap("Mapa6.txt",64);   
    tilemap.loadTile("graphics/Environment3.png");
    character=new Character(tilemap);
    character.setX(352);
    character.setY(512);
    }
    
    enemy=new ArrayList<Enemy>();
    if(stageNumber!=2 && stageNumber!=5){
    character=new Character(tilemap);
    character.setX(96);
    character.setY(96);
    }
    powerup=new ArrayList<PowerUp>();
    stageStartTimer=0;
    stageStartTimerDiff=0;
    stageStart=true;
   
    }
    
    public void update(){
        //new Stage
        if(stageStartTimer==0 && contEnemy==0 ){
           // running=false;
            stageNumber++;
            stageStart=false;
            stageStartTimer=System.nanoTime();
        }else{
         stageStartTimerDiff=(System.nanoTime()-stageStartTimer)/1000000;
         if(stageStartTimerDiff > stageDelay){
             stageStart=true;
             stageStartTimer=0;
             stageStartTimerDiff=0;  
         }
        
         //creando enemigos
         if(stageStart && contEnemy==0){
             createNewEnemies();
         }
         
        }
        //tilemap update
        tilemap.update();
        //character update
        character.update();
      //enemy update
        for(int i=0;i<enemy.size();i++){
        enemy.get(i).update();
        }
        //powerup update
         for(int i=0;i<powerup.size();i++){
        boolean remove= powerup.get(i).update();
        if(remove){
        powerup.remove(i);
        i--;
        }
        }
        
        
        for(int i=0;i<character.projectile.size();i++){
        //colssion projectile
            Projectile p=character.projectile.get(i);
            double px=p.getXp();
            double py=p.getYp();
            double pw=p.getw();
            
            
          for(int j=0;j<enemy.size();j++){
              Enemy e=enemy.get(j);
              double ex=e.getX();
              double ey=e.getY();
              double er=e.getR();
              double eh=p.geth();
              
              double dx=px-ex;
              double dy=py-ey;
              double dist=Math.sqrt(dx*dx+dy*dy);
              
              if(dist <pw/2+eh/2){
              e.hit();
              character.projectile.remove(i);
              i--;
              break;
              }
          }  
        }
         
        
        for(int k=0;k<enemy.size();k++){
        for(int i=0;i<enemy.get(k).projectile.size();i++){
        //colssion projectile
            ProjectileBoss ep=enemy.get(k).projectile.get(i);
            double epx=ep.getXp();
            double epy=ep.getYp();
            double epw=ep.getw();
            
            
        double cx=character.getx();
        double cy=character.gety();
        double cw=character.getw();
        double ch=character.geth();
              
              double dx=cx-epx;
              double dy=cy-epy;
              double dist=Math.sqrt(dx*dx+dy*dy);
              
              if(dist <cw/2+epw/2){
              character.loseLife();
              if(character.getLives()<=0){
                  running=false;
                  running2=false;
                  }
              enemy.get(k).projectile.remove(i);
              i--;
              break;
              }
          }  
        }
        
        
        
        
        //dead enemy
        for(int j=0;j<enemy.size();j++){
        if(enemy.get(j).isDead()){
               if(enemy.get(j).getRank() ==1 && (enemy.get(j).getType() ==1 ||enemy.get(j).getType() ==2 || enemy.get(j).getType() ==3 )){
             double rand=Math.random();
            if(rand > 0.010 && rand < 0.150) 
             powerup.add(new PowerUp(1,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));   
            else if(rand > 0.151 && rand < 0.250) 
            powerup.add(new PowerUp(2,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));
            else if(rand > 0.251 && rand < 0.260) 
            powerup.add(new PowerUp(3,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));
                }
               if(enemy.get(j).getRank() ==2 && (enemy.get(j).getType() ==1 ||enemy.get(j).getType() ==2 || enemy.get(j).getType() ==3 )){
             double rand=Math.random();
            if(rand > 0.010 && rand < 0.250) 
             powerup.add(new PowerUp(1,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));   
            else if(rand > 0.251 && rand < 0.450) 
            powerup.add(new PowerUp(2,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));
            else if(rand > 0.451 && rand < 0.550) 
            powerup.add(new PowerUp(3,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));
                }
             if(enemy.get(j).getRank() ==3 && (enemy.get(j).getType() ==1 ||enemy.get(j).getType() ==2 || enemy.get(j).getType() ==3 )){
             double rand=Math.random();
            if(rand > 0.001 && rand < 0.330) 
             powerup.add(new PowerUp(1,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));   
            else if(rand > 0.331 && rand < 0.660) 
            powerup.add(new PowerUp(2,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));
            else if(rand > 0.661 && rand < 0.999) 
            powerup.add(new PowerUp(3,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));
                }
            enemy.remove(j);
            
            j--;
             contEnemy--;         
            if(contEnemy==0){
            running2=false;}
            
            }
        }
        //player-enemies collision
        if(!character.isRecovering()){
        double cx=character.getx();
        double cy=character.gety();
        double cw=character.getw();
        double ch=character.geth();
            for(int i=0;i<enemy.size();i++){
            Enemy e=enemy.get(i);
              double ex=e.getX();
              double ey=e.getY();
              double er=e.getR();
              int ew=e.getWidth();
              double dx=cx-ex;
              double dy=cy-ey;
              double dist=Math.sqrt(dx*dx+dy*dy);
              
              if(dist< cw+ew ||dist< ch+ew){
                  //character.Shield();
                  character.loseLife();
                  if(character.getLives()<=0){
                  running=false;
                  running2=false;
                  }
              }
            }
        }
        
         for(int i=0;i<character.projectile.size();i++){
         if(character.projectile.get(i).getdy()==0 || character.projectile.get(i).getdx()==0){
         //.getdy()
             character.projectile.remove(i);
              i--;
         }  
         }
         
         for(int j=0;j<enemy.size();j++){
         for(int i=0;i<enemy.get(j).projectile.size();i++){
         if(enemy.get(j).projectile.get(i).getdy()==0 || enemy.get(j).projectile.get(i).getdx()==0){
         //.getdy()
             enemy.get(j).projectile.remove(i);
              i--;
         }  
         }
         }
        double cx=character.getx();
        double cy=character.gety();
        double cw=character.getw();
        double ch=character.geth();
         //character-powerup colission
         for(int i=0;i<powerup.size();i++){
            PowerUp p=powerup.get(i);
           double pux=p.getX();
           double puy=p.getY();
           double puw=p.getWidth();
           double dx= cx-pux;
           double dy=cy-puy;
           double dist=Math.sqrt(dx*dx+dy*dy);
           
           //
           if(dist<cw+puw){
           int type=p.getType();
             if(type==1){
             character.gainLife();
             }
             if(type==2){
             character.increasePower(1);
             }
             if(type==3){
             character.gainShield();
             }
               powerup.remove(i);
               i--;
           }
            } 
         
         //if(character.isDead()){
       // running=false;
        // }
    }
    
    public void render(){
        g.setColor(Color.BLACK);
        g.fillRect(0,0,width,height);
        tilemap.draw(g);
        character.draw(g);
        for(int i=0;i<enemy.size();i++){
        enemy.get(i).draw(g);
        }
        for(int i=0;i<powerup.size();i++){
        powerup.get(i).draw(g);
        }
        
        //Player lives
        for(int i=1; i<character.getLives()+1;i++){
        g.setColor(Color.WHITE);
        g.fillOval(20*i, 20, character.getr()*2, character.getr()*2);
        g.drawOval(20*i, 20, character.getr()*2, character.getr()*2);
       
        }
        //draw Stage number
        if(stageStartTimer !=0){
           g.setFont(new Font("Century Gothic",Font.PLAIN,60));
           String s="-S T A G E "+stageNumber+"  -";
           int length=(int)g.getFontMetrics().getStringBounds(s,g).getWidth();
           int alpha=(int)(255*Math.sin(3.14*stageStartTimerDiff/stageDelay));
           if(alpha>255)alpha=255;
           g.setColor(new Color(255,255,255,alpha));
           g.drawString(s, width/2-length/2,height/2 );
        }
        
        //draw player power
        g.setColor(Color.YELLOW);
        g.fillRect(20, 40, character.getPower()*10, 10);
        g.setColor(Color.YELLOW.darker());
        g.setStroke(new BasicStroke(2));
        for(int i=0;i<character.getRequiredPower();i++){
        g.drawRect(20+10*i,40,10,10);
        }
        
        for(int i=0; i<character.getShield();i++){
        g.setColor(Color.BLUE);
        g.fillRect(20+20*i, 60, 10, 10);
        g.setColor(Color.BLUE.darker());
        g.drawRect(20+20*i, 60, 10, 10);
     
        }
        
       
        
    }
    
    private void draw(){
    Graphics g2=getGraphics();
    g2.drawImage(image,0,0,(width),(height),null);//
    g2.dispose();
    }
    
    private void createNewEnemies(){
        enemy.clear();
        Enemy e;
        if(stageNumber==1){
        for(int i=0;i<3;i++){
    enemy.add(new Enemy(1,1,928,96,tilemap,true));
    contEnemy++;
    enemy.add(new Enemy(2,1,928,608,tilemap,true));
    contEnemy++;
     enemy.add(new Enemy(3,1,96,608,tilemap,true));
    contEnemy++;
    }
        }
        else if(stageNumber==2){
        for(int i=0;i<3;i++){
    enemy.add(new Enemy(3,1,928,608,tilemap,true));
    contEnemy++;
     enemy.add(new Enemy(2,1,96,608,tilemap,true));
    contEnemy++;
    enemy.add(new Enemy(1,1,928,96,tilemap,true));
    contEnemy++;
    }
      for(int i=0;i<2;i++){
    enemy.add(new Enemy(3,2,928,608,tilemap,true));
    contEnemy++;
     enemy.add(new Enemy(2,2,96,608,tilemap,true));
    contEnemy++;
    enemy.add(new Enemy(1,2,928,96,tilemap,true));
    contEnemy++;
    }  
        }
     else if(stageNumber==3){
        for(int i=0;i<1;i++){
    enemy.add(new Enemy(1,4,340,250,tilemap,true));
    contEnemy++;
        }   
        
        } 
     else if(stageNumber==4){
        for(int i=0;i<4;i++){
    enemy.add(new Enemy(1,1,928,96,tilemap,true));
    contEnemy++;
    enemy.add(new Enemy(2,1,928,608,tilemap,true));
    contEnemy++;
     enemy.add(new Enemy(3,1,96,608,tilemap,true));
    contEnemy++;
        }
        for(int i=0;i<1;i++){
    enemy.add(new Enemy(3,3,928,608,tilemap,true));
    contEnemy++;
     enemy.add(new Enemy(2,3,96,608,tilemap,true));
    contEnemy++;
    enemy.add(new Enemy(1,3,928,96,tilemap,true));
    contEnemy++;
    }    
        }else if(stageNumber==5){
        for(int i=0;i<3;i++){
    enemy.add(new Enemy(1,2,928,96,tilemap,true));
    contEnemy++;
    enemy.add(new Enemy(2,2,928,608,tilemap,true));
    contEnemy++;
     enemy.add(new Enemy(3,2,96,608,tilemap,true));
    contEnemy++;
        
        }
        for(int i=0;i<2;i++){
    enemy.add(new Enemy(3,3,928,608,tilemap,true));
    contEnemy++;
     enemy.add(new Enemy(2,3,96,608,tilemap,true));
    contEnemy++;
    enemy.add(new Enemy(1,3,928,96,tilemap,true));
    contEnemy++;
    }   
        
            }
        else if(stageNumber==6){
        for(int i=0;i<1;i++){
    enemy.add(new Enemy(2,4,340,250,tilemap,true));
    contEnemy++;
        } 
        }
        
            }
    
    public void keyTyped(KeyEvent key){}
    public void keyPressed(KeyEvent key){
    int code= key.getKeyCode();
    if (code==KeyEvent.VK_LEFT)
        character.setLeft(true);
    if (code==KeyEvent.VK_RIGHT)
        character.setRight(true);
    if (code==KeyEvent.VK_UP)
        character.setUp(true);
     if (code==KeyEvent.VK_DOWN)
        character.setDown(true);
     if (code==KeyEvent.VK_Z)
        character.setFiring(true);
    
    }
    public void keyReleased(KeyEvent key){
    int code= key.getKeyCode();
    if (code==KeyEvent.VK_LEFT)
        character.setLeft(false);
    if (code==KeyEvent.VK_RIGHT)
        character.setRight(false);
    if (code==KeyEvent.VK_UP)
        character.setUp(false);
     if (code==KeyEvent.VK_DOWN)
        character.setDown(false);
     if (code==KeyEvent.VK_Z)
        character.setFiring(false);
    }
    
    
    
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

