/*
 * To change this license header, choose License Headers in Prog2ect Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package game;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.ArrayList;
import MapGenerator.MazeGenerator;
/**
 *
 * @author twin
 */
public class GamePanelBackUp extends JPanel implements Runnable, KeyListener{
    
    public static final int height=600;
    public static final int width=600;
    
    private Thread thread;
    private boolean running;
    private BufferedImage image;
    private Graphics2D g;
    private final int FPS=30;
    private final int targetTime=1000/FPS;
    private Tilemap tilemap;
    private Character character;
    //public static Character character;
    public static ArrayList<Enemy> enemy;
    public static ArrayList<PowerUp> powerup;
    private int contEnemy;
    private long stageStartTimer;
    private long stageStartTimerDiff;
    private int stageNumber;
    private boolean stageStart;
    private int stageDelay=2500;
    //private MazeGenerator mg;
    public GamePanelBackUp(){
    super();
    setPreferredSize(new Dimension(width,height));
    setFocusable(true);
    requestFocus();
    
    }
    
    //@Override
    public void addNotify(){
    super.addNotify();
    if(thread==null){
    thread=new Thread(this);
    thread.start();
    }
    addKeyListener(this);
    }
   // mg.GenMapa();
    
    MazeGenerator mg=new MazeGenerator(5,5);
    //a=mg.GenMapa();
    
   // @Override
    public void run(){
       stageNumber=0;
       mg.GenMapa();
        while(true){
    init();
    long startTime;
    long urdTime;
    long waitTime;
    while(running){
        
       // System.out.println("hola");
    startTime=System.nanoTime();
    update(); 
    render();
    draw();
    urdTime=(System.nanoTime()-startTime)/1000000;
    waitTime=targetTime-urdTime;
    try{
    Thread.sleep(waitTime);
    }
    catch(Exception e){
    }
    }
        }
    }
    
    private void init(){
    running=true;
    image=new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
   
    g=(Graphics2D) image.getGraphics();
    //g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
    //g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    if(stageNumber==0){
    //tilemap=new Tilemap("testmap5.txt",64);
    tilemap=new Tilemap("Mapa1.txt",64);
    tilemap.loadTile("graphicsbackup/EnvironmentTIles3.png");
    }else if(stageNumber==1){
   // tilemap=new Tilemap("testmap4.txt",64);
    tilemap=new Tilemap("Mapa3.txt",64);   
    tilemap.loadTile("graphicsbackup/EnvironmentTIles3.png");
    }else if(stageNumber==2)
        System.exit(1);
    //if()
    character=new Character(tilemap);
    enemy=new ArrayList<Enemy>();
    character.setX(96);
    character.setY(96);
    powerup=new ArrayList<PowerUp>();
     
    
   /* for(int i=0;i<9;i++){
    enemy.add(new Enemy(1,1,300+i*30,300+i*20,tilemap,true));
    contEnemy++;
    }
    for(int i=0;i<9;i++){
    enemy.add(new Enemy(2,1,300+i*30,250+i*20,tilemap,true));
    contEnemy++;
    }
    */
    stageStartTimer=0;
    stageStartTimerDiff=0;
    stageStart=true;
    }
    
    public void update(){
        //new Stage
        if(stageStartTimer==0 && contEnemy==0 ){
           // running=false;
            stageNumber++;
            stageStart=false;
            stageStartTimer=System.nanoTime();
        }else{
         stageStartTimerDiff=(System.nanoTime()-stageStartTimer)/1000000;
         if(stageStartTimerDiff > stageDelay){
             stageStart=true;
             stageStartTimer=0;
             stageStartTimerDiff=0;  
         }
        
         //creando enemigos
         if(stageStart && contEnemy==0){
             createNewEnemies();
         }
         
        }
        //tilemap update
        tilemap.update();
        //character update
        character.update();
      //enemy update
        for(int i=0;i<enemy.size();i++){
        enemy.get(i).update();
        }
        //powerup update
         for(int i=0;i<powerup.size();i++){
        boolean remove= powerup.get(i).update();
        if(remove){
        powerup.remove(i);
        i--;
        }
        }
        
        
        for(int i=0;i<character.projectile.size();i++){
        //colssion projectile
            Projectile p=character.projectile.get(i);
            double px=p.getXp();
            double py=p.getYp();
            double pw=p.getw();
            
            
          for(int j=0;j<enemy.size();j++){
              Enemy e=enemy.get(j);
              double ex=e.getX();
              double ey=e.getY();
              double er=e.getR();
              double eh=p.geth();
              
              double dx=px-ex;
              double dy=py-ey;
              double dist=Math.sqrt(dx*dx+dy*dy);
              
              if(dist <pw/2+eh/2){
              e.hit();
              character.projectile.remove(i);
              i--;
              break;
              }
          }  
        }
        //dead enemy
        for(int j=0;j<enemy.size();j++){
        if(enemy.get(j).isDead()){
                enemy.get(j).update();
                 //Powerup chance
               if(enemy.get(j).getType() ==1){
             double rand=Math.random();
            if(rand > 0.001 && rand < 0.100) 
             powerup.add(new PowerUp(1,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));   
            else if(rand > 0.101 && rand < 1.00) 
            powerup.add(new PowerUp(2,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));   
                }
             if(enemy.get(j).getType() ==2){
             double rand=Math.random();
            if(rand > 0.001 && rand < 0.200) 
             powerup.add(new PowerUp(1,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));   
           // else if(rand > 0.501 && rand < 0.600) 
           // powerup.add(new PowerUp(2,enemy.get(j).getX(),enemy.get(j).getY(),tilemap));   
                }  
            enemy.remove(j);
            j--;
            contEnemy--;
            if(contEnemy==0){
            running=false;}
            }
        }
        //player-enemies collision
        if(!character.isRecovering()){
        double cx=character.getx();
        double cy=character.gety();
        double cw=character.getw();
        double ch=character.geth();
            for(int i=0;i<enemy.size();i++){
            Enemy e=enemy.get(i);
              double ex=e.getX();
              double ey=e.getY();
              double er=e.getR();
              int ew=e.getWidth();
              double dx=cx-ex;
              double dy=cy-ey;
              double dist=Math.sqrt(dx*dx+dy*dy);
              
              if(dist< cw+ew ||dist< ch+ew){
                  //character.Shield();
                  character.loseLife();
              }
            }
        }
        
         for(int i=0;i<character.projectile.size();i++){
         if(character.projectile.get(i).getdy()==0 || character.projectile.get(i).getdx()==0){
         //.getdy()
             character.projectile.remove(i);
              i--;
         }  
         }
        double cx=character.getx();
        double cy=character.gety();
        double cw=character.getw();
        double ch=character.geth();
         //character-powerup colission
         for(int i=0;i<powerup.size();i++){
            PowerUp p=powerup.get(i);
           double pux=p.getX();
           double puy=p.getY();
           double puw=p.getWidth();
           double dx= cx-pux;
           double dy=cy-puy;
           double dist=Math.sqrt(dx*dx+dy*dy);
           
           //
           if(dist<cw+puw){
           int type=p.getType();
             if(type==1){
             character.gainLife();
             }
             if(type==2){
             character.increasePower(1);
             }
               powerup.remove(i);
               i--;
           }
            } 
    }
    
    public void render(){
        g.setColor(Color.BLACK);
        g.fillRect(0,0,width,height);
        tilemap.draw(g);
        character.draw(g);
        for(int i=0;i<enemy.size();i++){
        enemy.get(i).draw(g);
        }
        for(int i=0;i<powerup.size();i++){
        powerup.get(i).draw(g);
        }
        
        //Player lives
        for(int i=1; i<character.getLives()+1;i++){
        g.setColor(Color.WHITE);
        g.fillOval(20*i, 20, character.getr()*2, character.getr()*2);
        g.drawOval(20*i, 20, character.getr()*2, character.getr()*2);
       // g.fillArc(i, i, width, height, targetTime, ABORT);
        }
        //draw Stage number
        if(stageStartTimer !=0){
           g.setFont(new Font("Century Gothic",Font.PLAIN,40));
           String s="-S T A G E "+stageNumber+"  -";
           int length=(int)g.getFontMetrics().getStringBounds(s,g).getWidth();
           int alpha=(int)(255*Math.sin(3.14*stageStartTimerDiff/stageDelay));
           if(alpha>255)alpha=255;
           g.setColor(new Color(255,255,255,alpha));
           g.drawString(s, width/2-length/2,height/2 );
        }
        
        //draw player power
        g.setColor(Color.YELLOW);
        g.fillRect(20, 40, character.getPower()*10, 10);
        g.setColor(Color.YELLOW.darker());
        g.setStroke(new BasicStroke(2));
        for(int i=0;i<character.getRequiredPower();i++){
        g.drawRect(20+10*i,40,10,10);
        }
        
    }
    
    private void draw(){
    Graphics g2=getGraphics();
    g2.drawImage(image,0,0,(width),(height),null);//
    g2.dispose();
    
    }
    
    private void createNewEnemies(){
        enemy.clear();
        Enemy e;
        if(stageNumber==1){
        for(int i=0;i<10;i++){
    enemy.add(new Enemy(1,1,928,96,tilemap,true));
    contEnemy++;
    enemy.add(new Enemy(2,1,928,608,tilemap,true));
    contEnemy++;
    }
        }
        if(stageNumber==2){
        for(int i=0;i<10;i++){
    enemy.add(new Enemy(1,1,928,96,tilemap,true));
    contEnemy++;
    enemy.add(new Enemy(2,1,928,608,tilemap,true));
    contEnemy++;
    }
        }
        
    }
    
    
    public void keyTyped(KeyEvent key){}
    public void keyPressed(KeyEvent key){
    int code= key.getKeyCode();
    if (code==KeyEvent.VK_LEFT)
        character.setLeft(true);
    if (code==KeyEvent.VK_RIGHT)
        character.setRight(true);
    if (code==KeyEvent.VK_UP)
        character.setUp(true);
     if (code==KeyEvent.VK_DOWN)
        character.setDown(true);
     if (code==KeyEvent.VK_Z)
        character.setFiring(true);
    
    }
    public void keyReleased(KeyEvent key){
    int code= key.getKeyCode();
    if (code==KeyEvent.VK_LEFT)
        character.setLeft(false);
    if (code==KeyEvent.VK_RIGHT)
        character.setRight(false);
    if (code==KeyEvent.VK_UP)
        character.setUp(false);
     if (code==KeyEvent.VK_DOWN)
        character.setDown(false);
     if (code==KeyEvent.VK_Z)
        character.setFiring(false);
    }
    
    
    
    }
    
    
    
    
    
    
    
    
    
    
    