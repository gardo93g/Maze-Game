/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package game;
import java.awt.*;

/**
 *
 * @author TWIN
 */
public class PowerUp {
    //
    private double x;
    private double y;
    private int width;
    private int height;
    private int type;
    private Color color1;
    private final Tilemap tilemap;
    //1 -> +1 life
    //2 --> +1 Shield
    //3 --> +1 power
    
    //Contstructor
    public PowerUp(int type,double x,double y,Tilemap tilemap){
    this.type=type;
    this.x=x;
    this.y=y;
    this.tilemap=tilemap;
    if(type==1){
        color1=Color.GREEN;
        width=16;
        height=16;
    }
    else if(type==2){
        color1=Color.YELLOW;
       width=16;
        height=16;
    }
    else if(type==3){
        color1=Color.BLUE;
       width=16;
        height=16;
    }
    
    }
    //Funcion
     public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }

    public int getType() {
        return type;
    }
    public boolean update(){
       if(y>GamePanel.height +height) 
       return true;
       else
        return false;
    }
    
    public void draw(Graphics2D g){
        int tx=tilemap.getX();
        int ty=tilemap.getY();
         int nx=  (int) (tx+x-width/2);
         int ny=  (int) (ty+y-height/2);
        //y+=1;
        g.setColor(color1);
       // g.fillRect((int) (x-r), (int)(y-r), 2*r, 2*r);
        g.fillRect(nx, ny, width, height);
        g.setStroke(new BasicStroke(3));
        g.setColor(color1.darker());
       // g.drawRect((int) (x-r), (int)(y-r), 2*r, 2*r);
        g.drawRect(nx, ny, width, height);
        
        g.setStroke(new BasicStroke(1));
       // g.setColor
        
    }
    
    
}
