/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package game;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 *
 * @author TWIN
 */
public class Projectile {
    //FIELD
    private double x;
    private double y;
    private  double dx;
    private  double dy;
    private  int r;
    private int width;
    private int height;
    private  double rad;
    private  double speed;
    private double stopSpeed;
     private Color color1;
     private final Tilemap tilemap;
     private Animation animation; 
    private boolean topleft;
    private boolean topright;
    private boolean botleft;
    private boolean botright;
      private BufferedImage[] bala;
     public Projectile(double angle,double x,double y,Tilemap tm){
         tilemap =tm;
         this.x=x;
         this.y=y;
         r=3;
         width=32;
         height=32;
         rad=Math.toRadians(angle);
         speed=7;
         dx=Math.cos(rad)*speed;
         dy=Math.sin(rad)*speed;
         //stopSpeed=0.01;
         
         color1=Color.YELLOW;
         try{
        bala=new BufferedImage[3];
       // bala[0]=ImageIO.read(new File("graphicsbackup/bala2.png"));
        BufferedImage proyectil=ImageIO.read(new File("graphics/bala4.png"));
        for(int i=0;i<3;i++){
        bala[i]=proyectil.getSubimage(i*width,0,width,height);
        }
         }catch(Exception e){
    e.printStackTrace();
    }
        animation=new Animation();  
     }
     //FUNCTIONS
     public double getXp(){
     return x;
     }
      public double getYp(){
     return y;
     }
       public double getRp(){
     return r;
     }
       public double getdy(){
     return dy;
     }
       public double getdx(){
     return dx;
     }  
       
     public int getw(){
    return width;
   }
   public int geth(){
   return height;
   }
       
     
     private void calculateCorners(double x,double y){
       int leftTile= tilemap.getColTile((int) (x-width/2));
       int rightTile= tilemap.getColTile((int) (x+width/2));
       int topTile= tilemap.getColTile((int) (y-height/2));
       int botTile= tilemap.getColTile((int) (y+height/2));
       topleft=tilemap.isBlocked(topTile, leftTile);
       topright=tilemap.isBlocked(topTile, rightTile);
       botleft=tilemap.isBlocked(botTile, leftTile);
       botright=tilemap.isBlocked(botTile, rightTile);
   }  
       
     public boolean update(){
     //x+=dx;
     //y+=dy;
        int tx=tilemap.getX();
        int ty=tilemap.getY();
        int nx=  (int) (tx+x-width);
        int ny=  (int) (ty+y-height);
     if(nx<-width/2||nx>GamePanel.width+width/2 || ny<-height/2||ny>GamePanel.height)
     return true;
     else{
      int currCol=tilemap.getColTile((int) x);
       int currRow=tilemap.getRowTile((int) y);
       double tempx=x;
       double tempy=y;
       
       double ndx=tempx+dx;   /// nd=nuevoDestino luego del update
       double ndy=tempy+dy;
       
       
       calculateCorners(x,ndy);
       if(dy<0){
       if(topleft||topright){
       dy=0;
       tempy=currRow*tilemap.getTileSize()+height/2;
       }
      else{
       tempy+=dy;
           }
      }
       if(dy>0){
           if(botleft||botright){
        dy=0;
        tempy=(currRow+0.998)*tilemap.getTileSize()-height/2;
       }
       else{
       tempy+=dy;
       }
     }
     calculateCorners(ndx,y);
       if(dx<0){
       if(topleft||botleft){
       dx=0;
       tempx=currCol*tilemap.getTileSize()+width/2;
       }
       else{
       tempx+=dx;
       } 
       }
       if(dx>0){
       if(topright||botright){  
           dx=0;
          tempx=(currCol+0.498)*tilemap.getTileSize()+width/2;
      }
       else{
           tempx+=dx;
       }
   }
       x=tempx;
       y=tempy;
       
     animation.setFrames(bala);
      animation.setDelay(50);
       animation.update();
      
     }
      
      return false;
     }

     
     public void draw(Graphics2D g){
     int tx=tilemap.getX();
     int ty=tilemap.getY();
         int nx=  (int) (tx+x-width/2);
         int ny=  (int) (ty+y-height/2);
     //g.setColor(color1);
    // g.fillOval(nx,ny, 4*r, 4*r);
         g.drawImage(animation.getImage(),nx,ny,null);
         
     }
     
     
}
