package game;
import java.awt.*;

/**
 *
 * @author TWIN
 */
public class Teleport {
    //
    private double x;
    private double y;
    private int width;
    private int height;
    private int type;
    private Color color1;
    private final Tilemap tilemap;
    //1 -> +1 life
    //2 --> +1 Shield
    //3 --> +1 power
    
    //Contstructor
    public Teleport(int type,double x,double y,Tilemap tilemap){
    this.type=type;
    this.x=x;
    this.y=y;
    this.tilemap=tilemap;
    if(type==1){
        color1=Color.WHITE;
        width=64;
        height=64;
    }
    }
    //Funcion
     public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }

    public int getType() {
        return type;
    }
    public boolean update(){
       if(y>GamePanel.height +height) 
       return true;
       else
        return false;
    }
    
    public void draw(Graphics2D g){
        int tx=tilemap.getX();
        int ty=tilemap.getY();
         int nx=  (int) (tx+x-width/2);
         int ny=  (int) (ty+y-height/2);
        //y+=1;
        g.setColor(color1);
       // g.fillRect((int) (x-r), (int)(y-r), 2*r, 2*r);
        g.fillRect(nx, ny, width, height);
        g.setStroke(new BasicStroke(3));
        g.setColor(color1.darker());
       // g.drawRect((int) (x-r), (int)(y-r), 2*r, 2*r);
        g.drawRect(nx, ny, width, height);
        
        g.setStroke(new BasicStroke(1));
       // g.setColor
        
    }
    
    
}